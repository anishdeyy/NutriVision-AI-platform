# 🌿 NutriVision AI v2 — Indian Diet Tracker
### Fully Fixed & Working Version

---

## ✅ What Was Fixed in This Version

| Issue | Fixed |
|-------|-------|
| "Start Tracking" not redirecting | ✅ Fully working onboarding → dashboard flow |
| Empty dashboard sections | ✅ All sections filled: ring, macros, pie, suggestion, meal plan, meal log |
| No footer | ✅ Starbucks-inspired footer with 5 columns |
| Bottom nav not working | ✅ All 5 nav items working |
| Log food modal broken | ✅ Food search, qty, bioavailability preview, add to log |
| No meal plan suggestions | ✅ AI suggests breakfast/lunch/dinner/snack based on goal + diet |
| History empty | ✅ 30-day auto-generated history + charts |
| Profile page empty | ✅ BMI, targets, tips all working |

---

## 🚀 How to Run (Super Easy — No Server Needed!)

### Option 1: Just Double-Click ⭐ EASIEST
1. Download/extract the ZIP
2. Double-click **`index.html`**
3. Opens in your browser instantly!

### Option 2: Python (if you have it)
```bash
cd NutriVision_v2
python -m http.server 8080
# Open: http://localhost:8080
```

### Option 3: VS Code Live Server
1. Install VS Code + "Live Server" extension
2. Right-click `index.html` → "Open with Live Server"

### Option 4: Node.js
```bash
npx serve .
# Opens at http://localhost:3000
```

---

## 📱 How to Use the App

### Step 1: Landing Page
- Click **"Start Tracking Free"** → begins onboarding
- Click **"Try Demo"** → instantly loads demo profile (Rahul Sharma, 72kg, cutting, non-veg)

### Step 2: Onboarding (4 Steps)
1. **Profile** → Name, email, age, weight, height
2. **Goal** → 🔥 Cutting / ⚖️ Maintain / 💪 Bulking
3. **Diet** → 🌿 Vegetarian / 🍗 Non-Vegetarian
4. **Summary** → See your BMI, daily calories & macros

### Step 3: Dashboard
- 🔥 **Calorie ring** — shows consumed vs goal
- 💪 **Macro bars** — protein, carbs, fats progress
- 🥧 **Pie chart** — macro percentage breakdown
- 🤖 **AI suggestion** — smart food chips to hit your goal
- 📋 **Meal plan** — AI-suggested breakfast/lunch/dinner/snack
- 🍽️ **Meal log** — click any meal row to log food

### Step 4: Log Food
- Tap **"+ Log Food"** or any meal row
- Search from 102+ Indian foods
- See **bioavailability score** and **effective protein**
- Adjust servings, click **"Add to Log"**

### Step 5: Analytics
- 7-day / 30-day calorie trend line chart
- Macro breakdown bar chart
- Daily log history list

### Step 6: Profile
- BMI with category (Underweight/Normal/Overweight/Obese)
- Daily calorie & macro targets
- Personalized nutrition tip

---

## 🍛 Food Database Highlights

| Category | Foods |
|----------|-------|
| Grains/Breads | Roti, Rice, Paratha, Naan, Idli, Dosa, Poha, Upma |
| Dal/Legumes | Dal Tadka, Rajma, Chana, Moong, Masoor, Sambar |
| Paneer/Veg | Palak Paneer, Butter Masala, Aloo Gobi, Bhindi |
| Non-Veg | Chicken Biryani, Tandoori, Butter Chicken, Fish Curry, Eggs |
| Snacks | Samosa, Pakora, Dhokla, Bhel, Makhana, Roasted Chana |
| Dairy | Milk, Dahi, Lassi, Chaas, Greek Yogurt, Whey Protein |
| Health | Sprouts, Soya Chunks, Sattu, Oats, Quinoa, Tofu |

---

## 🔬 Bioavailability Scoring

| Food Type | Score | Effective Protein |
|-----------|-------|-------------------|
| Eggs, Chicken, Fish | 1.0 (100%) | Full protein absorbed |
| Dairy (paneer, dahi) | 0.8 (80%) | Most absorbed |
| Legumes (dal, rajma) | 0.6 (60%) | Moderate |
| Wheat (roti, paratha) | 0.4 (40%) | Lower absorption |

---

## 📁 File Structure
```
NutriVision_v2/
└── index.html    ← Complete app (single file, no dependencies needed)
└── README.md     ← This file
```

---

Made with ❤️ for Indian fitness enthusiasts 🇮🇳
